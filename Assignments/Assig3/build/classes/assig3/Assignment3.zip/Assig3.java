import java.util.*;
import java.io.*;

public class Assig3 {

    public static void main(String[] args) throws IOException
    {
        //Scanner object
        Scanner inScan = new Scanner(System.in);

        String guess;
        
        String name;
        //starts tries with one because the first guess doesnt have a condition
        int tries = 0;
        boolean continue_playing = true;
        String keepPlaying;

        
        Scramble2 scramble = new Scramble2("words.txt");
        PlayerList playerList = new PlayerList("players.txt");
        Player p=null;
        String actualWord = scramble.getRealWord();
        String scrambledWord = scramble.getScrambledWord();        

        System.out.println("Welcome! What is your name? ('quit' to exit): ");
        name = inScan.nextLine();
        System.out.print("\n");
        
        while (continue_playing == true)
        {
            boolean exists=false;
            //checking to see if the player is in the playerlist array 
            for (int i= 0; i < playerList.playerList.size(); i++)
            {
                if (name.equalsIgnoreCase(playerList.playerList.get(i).getName()))
                {
                    exists=true;
                    p=playerList.playerList.get(i);
                    break;
                }               
            }
            //if the player is not already in the array, adds them to the array
            if (!exists)
            {
                p = new Player(name);
                playerList.addPlayer(p);
            }
            
            System.out.println(name + ", you have 3 guesses to get the Scrambled word! Good luck.");
            System.out.print("\n");
            System.out.println(scrambledWord.toUpperCase());
            System.out.print("\n");
            System.out.println("What do you think the scrambled word is?: ");
            
            guess = inScan.nextLine();
            tries = 1;
            int won =0;
            int lost=0;
            //lets the player guess up to three times for the scrambled word
            while (tries <= 3)
            {
                if (guess.equalsIgnoreCase(actualWord))
                {
                    
                    System.out.println("That is correct!\n");
                    p.wins();   
                    won++;
                    break;
                    
                }
                
                else if (guess.length() != actualWord.length())
                {
                    System.out.print("\n");
                    System.out.println("Your words arent the same length");
                    System.out.println("Try again");
                    System.out.println(scrambledWord.toUpperCase());
                    tries++;
                }
                
                else 
                    //shows the player what letters they got correct in the word
                {    
                    System.out.print("\n");
                    System.out.println("These are the letters you got correct");
                    for (int i=0; i < guess.length(); i++ )
                    {
                        if (Character.toLowerCase(guess.charAt(i)) == Character.toLowerCase(actualWord.charAt(i)))
                        {
                            System.out.print(guess.charAt(i));
                        }
                        else 
                            System.out.print("_");
                        
                    }
                    System.out.println("");
                    tries++;
                }
                System.out.print("\n");
                System.out.println("Guess again: ");
                guess = inScan.nextLine();

            }    
            if (tries == 4)
            {
                System.out.println("You used all your guesses, sorry!");
                System.out.print("\n");
                p.losses();
                lost++;
            }
            
            actualWord = scramble.getRealWord();
            scrambledWord = scramble.getScrambledWord(); 
            
            //asks player if they would like to continue playing 
            if (actualWord != null)
            {
                System.out.println("Would you like to continue playing?: ");
                keepPlaying = inScan.nextLine();
                System.out.print("\n");
            
                if (keepPlaying.equals("no"))
                {   
                    
                    //shows them scores from this game
                    System.out.println("Here are your scores from this game: ");
                    System.out.print("Wins: " + won + "\n");
                    System.out.print("Losses: " + lost + "\n");
                    System.out.print("Rounds: " + (won+lost) + "\n");
                    
                    //shows the cumulative scores
                    System.out.println("\n" + "Here are your cumulative scores: ");                   
                    System.out.print(p.toString());  
                    
                    //asks if there is another player waiting to play
                    continue_playing = false;
                    System.out.println("\n"+ "Is there another player waiting to play?: ");
                    String newPlayer;
                    newPlayer = inScan.nextLine();
                    if (newPlayer.equals("no"))
                    {
                        continue_playing = false;
                                         
                    }
                    else
                    {
                        scramble.reset();
                        System.out.println(" \nWelcome next player");
                        System.out.println("Enter your name to continue: ");
                        name = inScan.nextLine();
                        continue_playing = true;
                    }
                    
                } 
                
            }
            else 
            {
                System.out.println("There is no more words left in the file.");
                continue_playing = false;
            }
            
           
        }
        //saves player data to the file
        playerList.saveList();          
        System.out.print("\n");
        //prints out cumulative statistics
        System.out.print(playerList.toString());
        
    }
}

        

    