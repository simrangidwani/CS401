

public class Player {
    
   private String name;
   private int wins;
   private int losses;
   private int rounds;
   
   public Player(String n)
   {      
       name = n;
       wins = 0;
       losses = 0;
       rounds = 0;
   }
   
   public Player(String n, int r, int w, int l)
   {
       name = n;
       wins = w;
       losses = l;
       rounds = r;
   }
   
   public String toString()
   {
       StringBuilder sb = new StringBuilder();
       sb.append("Name: " + name + "\n");
       sb.append("Total Rounds Played: " + rounds + "\n");
       sb.append("Total Rounds Won: " + wins + "\n");
       sb.append("Total Rounds Lost: " + losses + "\n");
       return sb.toString();
   }
   
   
   public void wins()
   {
       wins++;
       rounds++;
   }
   
   public void losses()
   {
       losses++;
       rounds++;
   }
   
   public String toStringFile()
   {
       StringBuilder sb = new StringBuilder();
       sb.append(name + " " + rounds + " " + wins + " "+ losses);
       
       return sb.toString();
   }
   
   public String getName()
   {
       return name;
   }
   
   public int getWins()
   {
       return wins;
   }
   
   public int getLosses()
   {
       return losses;
   }
   
   public int getRounds()
   {
       rounds = wins+losses;
       return rounds;
   }
}
