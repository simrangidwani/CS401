
import java.util.*;
import java.io.*;


public class PlayerList {
    
    private int numPlayers;
    ArrayList<Player> playerList;
    String fileName;
    
    public PlayerList(String f) throws IOException
    {
        Scanner inputFile = new Scanner(new File(f));
        fileName = f;
        playerList = new ArrayList<Player>();
        
        while (inputFile.hasNextLine())
        {
            String [] player = inputFile.nextLine().split(" ");
            String name = player[0];
            int wins = Integer.parseInt(player[1]);
            int losses = Integer.parseInt(player[2]);
            int rounds = Integer.parseInt(player[3]);
            
            Player p = new Player(name, wins, losses, rounds);
            playerList.add(p);
        }

    }
    
    public void addPlayer(Player p)
    {
        playerList.add(p);
    }
    
    public Player getPlayer(String name)
    {
        for (int i=0; i< playerList.size(); i++)
        {
            if (playerList.get(i).getName().equals(name))
            {
                return playerList.get(i);
            }           
        }
        return null;
    }
    
    public Player removePlayer(String name)
    {
        for (int i=0; i < playerList.size(); i++)
        {
            if (playerList.get(i).getName().equals(name))
            {
                return playerList.remove(i);
            }               
        }
        return null;       
    }
  
    public void saveList() throws IOException
    {
        PrintWriter pw = new PrintWriter(new File (fileName));
        for (int i = 0; i < playerList.size(); i++)
        {
            pw.print(playerList.get(i).toStringFile() + "\n");
        }
        pw.close();
    }
    
    public String toStringAdmin()
    {
        StringBuilder sb = new StringBuilder();
        sb.append(this.toString());
        sb.append("\n\n");
        sb.append("Players: \n");
        for (int i = 0; i < playerList.size(); i++)
        {
            sb.append(playerList.get(i).toString());
            sb.append("\n");
        }
        return sb.toString();
    }
    
    
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        int totalWins = 0;
        int totalLosses = 0;
        int totalRounds = 0;
        int totalPlayers = 0;
        
        for (int i=0; i < playerList.size(); i++)
        {
            totalWins += playerList.get(i).getWins();
        }
        
        for (int i = 0; i < playerList.size(); i++)
        {
            totalLosses += playerList.get(i).getLosses();
        }
        
        for (int i = 0; i < playerList.size(); i++)
        {
            totalRounds += playerList.get(i).getRounds();
        }

        totalPlayers = playerList.size();
        float pct = ((float)totalWins/(float)totalRounds)*100;
        String formattedString = String.format("%.1f", pct);
        
        sb.append("Total Players: " + totalPlayers + "\n");
        sb.append("Total Rounds played: " + totalRounds + "\n");
        sb.append("Total Rounds Won: " + totalWins + "\n");
        sb.append("Total Rounds Lost: " + totalLosses + "\n");
        sb.append("Pct of Rounds Won: " + formattedString);
        return sb.toString();
    }
}


