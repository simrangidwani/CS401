import java.util.*;
import java.io.*;

public class Scramble2 {
    
    private Random rand;
    private boolean scrambled;
    private File file;
    private Scanner inputFile;
    private String lastWord;
    ArrayList<String> listS;
    int count;
    private boolean newScrambled;
    String scrambledWord;
    
    public Scramble2(String fileName) throws IOException {
        
        file = new File(fileName);
        inputFile = new Scanner(file);
        rand = new Random();
        scrambled = true;
        newScrambled = true;
        
        listS = new ArrayList<String>();
        while (inputFile.hasNextLine()) {
            listS.add(inputFile.nextLine());
        }
        Collections.shuffle(listS);
        
        count = 0;
    }
        
    public String getRealWord() {
       
        
            if (scrambled == false)
            {
                return lastWord;
            }
            else if (count < listS.size() && scrambled)
            {
             
                 lastWord = listS.get(count);
                 count++;
                 scrambled = false;
                 newScrambled = true;
                 return lastWord;
            }
            else
                return null;
        }
        
    public String getScrambledWord() {
  
        char temp = 0;
        int lastWordlength = lastWord.length();
        
        
        
        if(lastWord != null && newScrambled)
        {
            StringBuilder sb = new StringBuilder(lastWord);
            for (int i=0; i < lastWord.length(); i++)
            {             
                
                int index1 = rand.nextInt(lastWordlength);
                int index2 = rand.nextInt(lastWordlength);
                char charac1 = sb.charAt(index1);
                char charac2 = sb.charAt(index2);
                sb.setCharAt(index1, charac2);
                sb.setCharAt(index2, charac1);

            }
            scrambled = true;
            newScrambled = false;
            scrambledWord = sb.toString();
            return scrambledWord;
          
            
        }
        else
            return scrambledWord;       
    }
        
    public void reset(){
          Collections.shuffle(listS);
          count = 0;
          scrambled = true;
    }
}
    
    
